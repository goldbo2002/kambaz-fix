import React, { useEffect } from "react";
import { useAppDispatch } from '../redux/store';
import { verifySession } from "../redux/authSlice";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(verifySession());
  }, [dispatch]);

  return (
    <div>
      <h2>Dashboard</h2>
      <nav>
        <Link to="/Labs/Lab1">Lab1</Link> •
        <Link to="/Labs/Lab2">Lab2</Link> •
        <Link to="/Labs/Lab3">Lab3</Link> •
        <Link to="/Labs/Lab4">Lab4</Link> •
        <Link to="/Labs/Lab5">Lab5</Link> •
        <Link to="/Labs/Lab6">Lab6</Link> •
        <Link to="/Courses">Courses</Link> •
        <Link to="/Assignments">Assignments</Link>
        <a href="/Labs/Lab1">Back to Lab 1</a>

      </nav>
    </div>
  );
}
